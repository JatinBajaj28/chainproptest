"""
vulnalyzer.graph.ai_patches
============================
Generate AI-powered patch recommendations using Groq LLM API.

Requires a Groq API key from https://console.groq.com/keys

Usage:
    from vulnalyzer.graph.ai_patches import GroqPatchReporter

    reporter = GroqPatchReporter(api_key="YOUR_GROQ_API_KEY")
    report = reporter.generate_report(scan_result)
"""

from __future__ import annotations

import json
import logging
import os
import urllib.request
import urllib.error
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from vulnalyzer.scanner.engine import ScanResult, Finding

logger = logging.getLogger(__name__)

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL   = "llama3-8b-8192"


class GroqPatchReporter:
    """Generate AI-powered vulnerability reports using Groq LLM."""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("GROQ_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Groq API key required.\n"
                "  Get a free key at: https://console.groq.com/keys\n"
                "  Then set GROQ_API_KEY environment variable."
            )

    def _call_groq(self, prompt: str, max_tokens: int = 2048) -> str:
        """Make a raw HTTP POST to the Groq chat completions endpoint."""
        payload = json.dumps({
            "model": GROQ_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.2,
        }).encode("utf-8")

        req = urllib.request.Request(
            GROQ_API_URL,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Groq API error {e.code}: {body}") from e

        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            raise RuntimeError(f"Unexpected Groq response: {json.dumps(data)}") from e

    def generate_report(self, scan_result: "ScanResult") -> str:
        """
        Generate a full Groq-powered vulnerability report for a scan result.
        Returns a markdown string.
        """
        from datetime import datetime, timezone

        findings = scan_result.findings
        now = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")

        if not findings:
            return (
                f"## ✅ No Vulnerabilities Found\n\n"
                f"Repository `{scan_result.repo_url}` appears clean — "
                f"no known CVEs detected in its dependency tree.\n"
            )

        # Build a compact finding list for the prompt
        finding_lines = []
        for f in findings:
            fixed = f.fixed_versions[0] if f.fixed_versions else "none"
            dep = "direct" if f.is_direct else "transitive"
            finding_lines.append(
                f"- CVE/OSV: {f.osv_id} | Severity: {f.severity} | "
                f"Package: {f.package_name}@{f.version_found} ({f.ecosystem}) | "
                f"Type: {dep} | Fix: {fixed} | Summary: {f.summary}"
            )

        prompt = f"""You are a senior application security engineer.
Analyze the following vulnerability scan results and produce a concise, actionable Markdown report.

Repository: {scan_result.repo_url}
Branch: {scan_result.branch_ref}
Commit: {scan_result.revision_id[:12] if scan_result.revision_id else 'unknown'}
Scan date: {now}
Total findings: {len(findings)}

FINDINGS:
{chr(10).join(finding_lines)}

Write a Markdown report with these sections:
1. **Executive Summary** (2-3 sentences: overall risk, most critical issues)
2. **Critical & High Findings** (table: Package | CVE | Severity | Installed | Fix Version)
3. **Recommended Actions** (numbered list, prioritized by severity — exact upgrade commands where possible)
4. **Medium & Low Findings** (brief bullet list)

Rules:
- Be concrete: use exact package names, CVE IDs, and version numbers from the findings above
- For each Critical/High CVE, give the specific upgrade command (npm install pkg@x.y.z, pip install pkg==x.y.z, etc.)
- Keep the total report under 600 words
- Do NOT mention Gemini, Google, or any other AI provider
- Return ONLY the Markdown — no preamble, no trailing note"""

        try:
            content = self._call_groq(prompt)
        except Exception as exc:
            logger.warning("Groq report generation failed: %s", exc)
            # Return a clean fallback report without AI
            content = self._fallback_report(scan_result, now)

        return content

    def _fallback_report(self, scan_result: "ScanResult", now: str) -> str:
        """Structured report without AI when Groq is unavailable."""
        from datetime import datetime, timezone

        findings = scan_result.findings
        lines = [
            f"## 🔐 Vulnerability Report — {scan_result.repo_url}",
            f"",
            f"*Scan date: {now}  ·  Commit: {(scan_result.revision_id or '')[:12]}  ·  Branch: {scan_result.branch_ref}*",
            f"",
            f"**Total findings: {len(findings)}**",
            f"",
            "| Package | CVE / OSV | Severity | Installed | Fix Version |",
            "|---------|-----------|----------|-----------|-------------|",
        ]
        for f in sorted(findings, key=lambda x: {"CRITICAL":4,"HIGH":3,"MEDIUM":2,"LOW":1}.get(x.severity.upper(),0), reverse=True):
            fix = f.fixed_versions[0] if f.fixed_versions else "—"
            lines.append(f"| `{f.package_name}` | {f.osv_id} | **{f.severity}** | {f.version_found} | {fix} |")
        lines += ["", "### Recommended Actions", ""]
        for i, f in enumerate(sorted(findings, key=lambda x: {"CRITICAL":4,"HIGH":3,"MEDIUM":2,"LOW":1}.get(x.severity.upper(),0), reverse=True), 1):
            if f.fixed_versions:
                lines.append(f"{i}. Upgrade `{f.package_name}` from `{f.version_found}` → `{f.fixed_versions[0]}` ({f.osv_id})")
            else:
                lines.append(f"{i}. Monitor `{f.package_name}@{f.version_found}` — no fix yet for {f.osv_id}")
        return "\n".join(lines)
